﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class GeneratePrimes
{
    static public int ApproximatePlaceOfNthPrime(int n)
    {
        return (n * n) - n + 41;
    }
    /* generate primes to limit a vector using seive of erathosenes */
    /* limit is the nth prime so the array needs to be made larger by
     * and estimate */
    public static int[] GeneratePrimesList(int limit)
    {
        /* need to estimate array size needed */
        var arraySize = ApproximatePlaceOfNthPrime(limit);

        int[] isPrime = new int[arraySize];

        SetAllToPrime(isPrime);
        isPrime[0] = 0;
        isPrime[1] = 0;
        Sieve(isPrime);

        return isPrime;
    }

    static void SetAllToPrime(int[] isPrime)
    {
        for (int i = 0; i < isPrime.Length; i++)
        {
            isPrime[i] = 1;
        }
    }

    static void Sieve(int[] isPrime)
    {
        int i = 2;
        while (i * i <= isPrime.Length)
        {
            if (isPrime[i] == 0)
            {
                i++;
                continue;
            }
            int j = 2 * i;
            while (j < isPrime.Length)
            {
                isPrime[j] = 0;
                j += i;
            }
            i++;
        }
    }
}

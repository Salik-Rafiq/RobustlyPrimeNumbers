﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class CheckPrime
{
    public static bool isCandidatePrime(int candidate)
    {
        if (candidate == 1) 
        {
            return false;
        }
        int limit = (int)Math.Sqrt(candidate);
        for (int i = 2; i <= limit; i++)
        {
            if ((candidate % i) == 0)
            {
                return false;
            }
        }
        return true;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class CheckIsRPN
{
    public static int isRPN(int candidate)
    {
        /* convert to string and substring the digits out, no "0" allowed */
        string strCandidate = candidate.ToString();
        if (strCandidate.Contains("0"))
        {
            return 0;
        }
        strCandidate = strCandidate.Remove(0, 1);

        while (strCandidate.Length > 0)
        {
            int subCandidate = int.Parse(strCandidate);

            if (!CheckPrime.isCandidatePrime(subCandidate))
            {
                return 0;
            }
            strCandidate = strCandidate.Remove(0, 1);
        }
        return 1;
    }

}
